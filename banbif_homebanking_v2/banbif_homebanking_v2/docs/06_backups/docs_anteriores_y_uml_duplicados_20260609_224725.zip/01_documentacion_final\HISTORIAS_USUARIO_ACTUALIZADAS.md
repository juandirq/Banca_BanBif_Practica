# HISTORIAS DE USUARIO ACTUALIZADAS

## Cliente

HU01: Como cliente, quiero registrarme para acceder al homebanking.
HU02: Como cliente, quiero iniciar sesion para ver mis productos.
HU03: Como cliente, quiero abrir una Cuenta Ahorro Digital.
HU04: Como cliente, quiero depositar dinero en mi cuenta.
HU05: Como cliente, quiero pagar servicios.
HU06: Como cliente, quiero pagar una tarjeta de credito BanBif ya existente.
HU07: Como cliente, quiero transferir a otra cuenta BanBif.
HU08: Como cliente, quiero enviar dinero por PLIN interoperable.
HU09: Como cliente, quiero solicitar un Prestamo Efectivo BanBif.
HU10: Como cliente, quiero solicitar un Credito Vehicular BanBif.

## Core financiero

HU11: Como analista, quiero revisar solicitudes asignadas.
HU12: Como analista autorizado, quiero aprobar, rechazar o derivar solicitudes.
HU13: Como usuario de riesgos, quiero gestionar recuperaciones.
HU14: Como admin agencia, quiero desembolsar creditos aprobados.
HU15: Como admin core, quiero supervisar el sistema sin modificar decisiones operativas.
