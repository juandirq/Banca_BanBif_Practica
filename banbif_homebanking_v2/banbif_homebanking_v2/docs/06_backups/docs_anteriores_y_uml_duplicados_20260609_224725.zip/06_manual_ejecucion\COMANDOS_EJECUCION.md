# MANUAL DE EJECUCION

## Backend cliente

cd C:\Users\Lenovo\Desktop\banbif_homebanking_v2\portal-banbif-backend
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload

## Frontend cliente

cd C:\Users\Lenovo\Desktop\banbif_homebanking_v2\portal-banbif-frontend
npm.cmd run dev

## Backend core financiero

cd C:\Users\Lenovo\Desktop\banbif_homebanking_v2\core-financiero-backend
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
python -m uvicorn app.main:app --host 127.0.0.1 --port 8001 --reload

## Frontend core financiero

cd C:\Users\Lenovo\Desktop\banbif_homebanking_v2\core-financiero-frontend
npm.cmd run dev -- --host 127.0.0.1 --port 5174

## Usuarios internos demo

admin.core / Admin123
ana.rojas / Analista123
luis.paredes / Analista123
jorge.medina / Analista123
comite.creditos / Analista123
gerencia.finanzas / Analista123
admin.agencia / Agencia123
