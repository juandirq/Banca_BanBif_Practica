# RESUMEN FUNCIONAL FINAL

## Portal cliente

El portal cliente permite registro, login, consulta de dashboard, apertura de Cuenta Ahorro Digital, deposito, pagos, transferencias, PLIN interoperable y solicitud de creditos.

## Core financiero

El core financiero permite que los roles internos gestionen el ciclo crediticio: analistas eval?an, riesgos gestiona recuperaciones, comite/gerencia revisan casos fuertes, admin agencia desembolsa y admin core supervisa.

## Logica bancaria implementada

- Cuenta Ahorro Digital desde homebanking.
- Cuenta Sueldo y Cuenta Corriente no se abren libremente.
- Pagos con Token Digital.
- Tarjeta de credito BanBif ya existente con pago minimo referencial de S/ 30.
- Transferencia bancaria con saldo y token.
- PLIN interoperable con celular peruano de 9 digitos que inicia con 9.
- PLIN minimo S/ 1, maximo S/ 500 por operacion y maximo diario S/ 2,000.
- Prestamo Efectivo BanBif con cuota referencial S/ 585.08 para S/ 5,000 a 12 meses.
- Credito Vehicular BanBif con monto minimo S/ 15,000.
