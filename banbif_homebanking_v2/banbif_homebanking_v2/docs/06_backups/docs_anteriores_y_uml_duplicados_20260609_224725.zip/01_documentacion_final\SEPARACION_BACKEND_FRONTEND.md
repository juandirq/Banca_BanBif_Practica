# SEPARACION BACKEND / FRONTEND

## Backend

El backend contiene la logica real del negocio:

- Autenticacion y proteccion de rutas.
- Validacion de Token Digital.
- Validacion de saldo.
- Apertura de cuentas.
- Bloqueo de productos que requieren evaluacion.
- Pagos.
- Transferencias.
- PLIN interoperable.
- Validacion de creditos.
- Reglas de roles internos.
- Desembolsos.
- Recuperaciones.
- Vistas para Power BI.

## Frontend

El frontend contiene la capa visual:

- Formularios.
- Navegacion.
- Mensajes.
- Tablas.
- Dashboard.
- Vista previa de operaciones.
- Simulacion visual referencial para orientar al cliente.

## Regla aplicada

El frontend orienta, pero el backend decide. Toda validacion importante se encuentra en backend.
