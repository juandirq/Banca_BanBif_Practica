# VISTAS PARA POWER BI

## Vistas listas

- cuentas
- transacciones
- solicitudes_prestamo
- vw_pbi_operaciones_banbif
- vw_pbi_resumen_general
- vw_pbi_clientes

## Uso recomendado

### vw_pbi_operaciones_banbif
Para graficos por modulo, tipo, estado, monto, fecha, anio y anio_mes.

### vw_pbi_resumen_general
Para KPIs por cliente: total de cuentas, saldo total, transacciones, pagos, creditos, desembolsos y casos de mora.

### vw_pbi_clientes
Para segmentadores y detalle de clientes.

## Visuales sugeridos

- Tarjeta: total clientes.
- Tarjeta: saldo total.
- Tarjeta: operaciones totales.
- Tarjeta: creditos solicitados.
- Barras: operaciones por modulo.
- Lineas: operaciones por mes.
- Circular: estados de credito.
- Tabla: cliente, saldo, pagos, creditos y mora.
