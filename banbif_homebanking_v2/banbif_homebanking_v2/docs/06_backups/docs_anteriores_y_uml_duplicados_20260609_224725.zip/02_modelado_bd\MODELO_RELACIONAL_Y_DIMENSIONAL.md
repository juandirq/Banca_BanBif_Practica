# MODELO DE BASE DE DATOS

## 1. Modelo relacional

### user
Representa a los clientes del homebanking.
Campos principales: id, name, document, email, phone, address, password_hash, role, is_active, created_at.

### account
Representa cuentas bancarias del cliente.
Campos principales: id, user_id, account_number, type/account_type, currency, balance, status, created_at.

Relacion:
user 1 a N account.

### movement
Representa movimientos de cuentas.
Campos principales: id, account_id, description, operation_type, amount, created_at.

Relacion:
account 1 a N movement.

### pagos
Representa pagos de servicios, tarjeta o prestamo.
Campos principales: id, user_id, account_id, servicio/service, numero_contrato/contract_number, monto/amount, estado/status, created_at.

Relacion:
user 1 a N pagos.
account 1 a N pagos.

### creditapplication
Representa solicitudes de credito.
Campos principales: id, user_id, product, amount, term_months/months, monthly_income, purpose, status, analyst_comment, created_at.

Relacion:
user 1 a N creditapplication.

### core_analyst_user
Representa usuarios internos del core.
Campos principales: id, username, full_name, email, role, is_active, created_at.

## 2. Vistas relacionales en espanol

### cuentas
Vista de cuentas con nombres en espanol para consulta y Power BI.

### transacciones
Vista de movimientos/transacciones con cliente y cuenta.

### solicitudes_prestamo
Vista de solicitudes de credito con campos de riesgo, cuota, ruta y desembolso.

## 3. Modelo dimensional para Power BI

### DimCliente
Fuente: vw_pbi_clientes.
Campos: cliente_id, documento, cliente_nombre, email, telefono, direccion, rol, activo, fecha_registro, anio_registro.

### DimTiempo
Derivada desde campos fecha de vw_pbi_operaciones_banbif.
Campos: fecha, anio, anio_mes.

### DimModulo
Derivada de vw_pbi_operaciones_banbif.
Campos: modulo, tipo, estado.

### FactOperaciones
Fuente: vw_pbi_operaciones_banbif.
Medidas: conteo de operaciones, suma de monto, operaciones por modulo, operaciones por mes.

### FactResumenCliente
Fuente: vw_pbi_resumen_general.
Medidas: total_cuentas, saldo_total, total_transacciones, total_pagos, total_creditos, total_desembolsos, total_casos_mora.

## 4. Orden recomendado para explicar al profesor

Primero se explica el modelo relacional porque representa la operacion real de la banca.
Luego se explica el modelo dimensional porque deriva de las vistas y sirve para Power BI.
