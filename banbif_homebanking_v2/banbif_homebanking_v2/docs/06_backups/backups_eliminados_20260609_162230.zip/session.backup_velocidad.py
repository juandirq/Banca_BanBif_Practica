﻿import time
from sqlalchemy import create_engine, text
from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import NullPool
from app.core.config import settings


def normalize_database_url(url: str) -> str:
    if url.startswith("postgresql://"):
        url = url.replace("postgresql://", "postgresql+psycopg://", 1)

    # Supabase necesita SSL; si no esta en la URL, lo agregamos.
    if "sslmode=" not in url:
        separator = "&" if "?" in url else "?"
        url = f"{url}{separator}sslmode=require"

    return url


database_url = normalize_database_url(settings.database_url)

connect_args = {
    "connect_timeout": 10,
}

# Importante para Supabase Transaction Pooler, normalmente puerto 6543
if ":6543" in settings.database_url:
    connect_args["prepare_threshold"] = None

engine = create_engine(
    database_url,
    echo=False,
    pool_pre_ping=True,
    poolclass=NullPool,
    connect_args=connect_args,
)

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine,
)


def create_safe_session():
    last_error = None

    for _ in range(3):
        db = SessionLocal()
        try:
            db.execute(text("SELECT 1"))
            return db
        except OperationalError as error:
            last_error = error
            db.close()
            engine.dispose()
            time.sleep(0.7)

    raise last_error


def get_db():
    db = create_safe_session()
    try:
        yield db
    finally:
        db.close()


def check_database_connection():
    last_error = None

    for _ in range(3):
        try:
            with engine.connect() as conn:
                return conn.execute(text("SELECT NOW() AS current_time")).fetchone()
        except OperationalError as error:
            last_error = error
            engine.dispose()
            time.sleep(0.7)

    raise last_error
