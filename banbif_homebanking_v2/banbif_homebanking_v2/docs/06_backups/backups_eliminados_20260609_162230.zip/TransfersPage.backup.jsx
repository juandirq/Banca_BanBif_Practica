import { Send } from "lucide-react";
import { money, maskAccount, getAccountById } from "../utils/format";
import { getBalanceAfterOperation, isInsufficientBalance } from "../utils/banking";

export default function TransfersPage({
  accounts,
  movements,
  transferForm,
  setTransferForm,
  makeTransfer,
  loading,
  onFeedback,
}) {
  const selectedAccount = getAccountById(accounts, transferForm.from_account_id);
  const balanceAfter = getBalanceAfterOperation(selectedAccount?.balance, transferForm.amount);
  const insufficient = selectedAccount && isInsufficientBalance(selectedAccount.balance, transferForm.amount);

  const transferMovements = movements.filter((m) =>
    String(m.operation_type || "").toLowerCase().includes("transferencia")
  );

  function copyAccount(number) {
    navigator.clipboard?.writeText(number);
    onFeedback("Numero de cuenta copiado.", "success");
  }

  return (
    <section className="page-stack">
      <div className="page-title">
        <span className="section-label">Modulo de transferencias</span>
        <h2>Enviar dinero</h2>
        <p>Transfiere entre cuentas registradas, revisando saldo disponible antes de confirmar.</p>
      </div>

      <section className="two-columns">
        <article className="panel">
          <h2>Nueva transferencia</h2>

          <form className="form" onSubmit={makeTransfer}>
            <label>Cuenta origen</label>
            <select
              value={transferForm.from_account_id}
              onChange={(e) => setTransferForm({ ...transferForm, from_account_id: e.target.value })}
              required
            >
              <option value="">Selecciona cuenta origen</option>
              {accounts.map((account) => (
                <option value={account.id} key={account.id}>
                  {maskAccount(account.account_number)} - {money(account.balance)}
                </option>
              ))}
            </select>

            <label>Cuenta destino</label>
            <input
              value={transferForm.to_account_number}
              onChange={(e) => setTransferForm({ ...transferForm, to_account_number: e.target.value })}
              placeholder="Numero de cuenta destino"
              required
            />

            <label>Monto</label>
            <input
              type="number"
              value={transferForm.amount}
              onChange={(e) => setTransferForm({ ...transferForm, amount: e.target.value })}
              placeholder="Monto a transferir"
              min="1"
              required
            />

            <label>Descripcion</label>
            <input
              value={transferForm.description}
              onChange={(e) => setTransferForm({ ...transferForm, description: e.target.value })}
              placeholder="Descripcion de la transferencia"
            />

            <label className="check-line">
              <input
                type="checkbox"
                checked={transferForm.confirm_transfer}
                onChange={(e) => setTransferForm({ ...transferForm, confirm_transfer: e.target.checked })}
              />
              Confirmo cuenta destino, monto y cuenta origen.
            </label>

            <button className="primary" disabled={loading || insufficient}>
              <Send size={17} />
              Transferir
            </button>
          </form>
        </article>

        <article className="panel">
          <h2>Vista previa</h2>

          {!selectedAccount ? (
            <p className="empty">Selecciona una cuenta origen para calcular la transferencia.</p>
          ) : (
            <div className="preview-box">
              <div>
                <span>Cuenta origen</span>
                <strong>{maskAccount(selectedAccount.account_number)}</strong>
              </div>
              <div>
                <span>Saldo actual</span>
                <strong>{money(selectedAccount.balance)}</strong>
              </div>
              <div>
                <span>Monto a transferir</span>
                <strong className="negative">{money(transferForm.amount)}</strong>
              </div>
              <div>
                <span>Saldo despues</span>
                <strong className={balanceAfter < 0 ? "negative" : "positive"}>
                  {money(balanceAfter)}
                </strong>
              </div>

              {insufficient && (
                <p className="danger-note">Saldo insuficiente para realizar la transferencia.</p>
              )}
            </div>
          )}
        </article>
      </section>

      <section className="panel">
        <h2>Cuentas disponibles</h2>
        <div className="account-list">
          {accounts.map((account) => (
            <div className="simple-account" key={account.id}>
              <strong>{maskAccount(account.account_number)}</strong>
              <span>{account.account_type} Ã‚Â· {account.status}</span>
              <b>{money(account.balance)}</b>
              <button className="mini-link" onClick={() => copyAccount(account.account_number)}>
                Copiar numero
              </button>
            </div>
          ))}
        </div>
      </section>

      <section className="panel">
        <h2>Ultimas transferencias</h2>
        <div className="table">
          {transferMovements.length === 0 ? (
            <p className="empty">No hay transferencias recientes.</p>
          ) : (
            transferMovements.map((m) => (
              <div className="row" key={m.id}>
                <div>
                  <strong>{m.description}</strong>
                  <span>{m.operation_type}</span>
                </div>
                <b className={Number(m.amount) < 0 ? "negative" : "positive"}>
                  {money(m.amount)}
                </b>
              </div>
            ))
          )}
        </div>
      </section>
    </section>
  );
}