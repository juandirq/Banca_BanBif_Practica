import { useEffect, useState } from "react";
import {
  Landmark,
  ShieldCheck,
  Wallet,
  CreditCard,
  Send,
  Receipt,
  PiggyBank,
  LogOut,
  RefreshCcw,
} from "lucide-react";
import api from "./services/api";

const initialLogin = {
  identifier: "",
  password: "",
};

const initialRegister = {
  name: "",
  email: "",
  document: "",
  password: "",
};

function money(value) {
  return `S/ ${Number(value || 0).toFixed(2)}`;
}

export default function App() {
  const [mode, setMode] = useState("login");
  const [user, setUser] = useState(null);
  const [dashboard, setDashboard] = useState(null);
  const [loginForm, setLoginForm] = useState(initialLogin);
  const [registerForm, setRegisterForm] = useState(initialRegister);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  const [depositForm, setDepositForm] = useState({
    account_id: "",
    amount: "",
    description: "Deposito desde portal BanBif",
  });

  const [paymentForm, setPaymentForm] = useState({
    account_id: "",
    service: "Luz",
    contract_number: "",
    amount: "",
  });

  const [transferForm, setTransferForm] = useState({
    from_account_id: "",
    to_account_number: "",
    amount: "",
    description: "Transferencia desde portal BanBif",
  });

  const [creditForm, setCreditForm] = useState({
    product: "Credito personal",
    amount: "",
    term_months: "12",
    monthly_income: "",
    purpose: "",
  });

  useEffect(() => {
    const savedUser = localStorage.getItem("banbif_user");
    const savedToken = localStorage.getItem("banbif_token");

    if (savedToken && savedUser) {
      setUser(JSON.parse(savedUser));
      loadDashboard();
    }
  }, []);

  async function loadDashboard() {
    try {
      const response = await api.get("/api/dashboard");
      setDashboard(response.data);
    } catch {
      localStorage.removeItem("banbif_token");
      localStorage.removeItem("banbif_user");
      setUser(null);
      setDashboard(null);
    }
  }

  async function handleLogin(e) {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    try {
      const response = await api.post("/api/login", loginForm);

      localStorage.setItem("banbif_token", response.data.access_token);
      localStorage.setItem("banbif_user", JSON.stringify(response.data.user));

      setUser(response.data.user);
      setDashboard(response.data.dashboard_preview);
      setMessage("Sesion iniciada correctamente.");

      await loadDashboard();
    } catch (error) {
      setMessage(error.response?.data?.detail || "No se pudo iniciar sesion.");
    } finally {
      setLoading(false);
    }
  }

  async function handleRegister(e) {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    try {
      const response = await api.post("/api/register", registerForm);

      localStorage.setItem("banbif_token", response.data.access_token);
      localStorage.setItem("banbif_user", JSON.stringify(response.data.user));

      setUser(response.data.user);
      setDashboard(response.data.dashboard_preview);
      setMessage("Cuenta creada y sesion iniciada correctamente.");

      await loadDashboard();
    } catch (error) {
      setMessage(error.response?.data?.detail || "No se pudo registrar el usuario.");
    } finally {
      setLoading(false);
    }
  }

  function logout() {
    localStorage.removeItem("banbif_token");
    localStorage.removeItem("banbif_user");
    setUser(null);
    setDashboard(null);
    setLoginForm(initialLogin);
    setMessage("Sesion cerrada correctamente.");
  }

  async function createAccount() {
    const ok = window.confirm("Deseas abrir una nueva cuenta de ahorros?");
    if (!ok) return;

    setLoading(true);
    setMessage("");

    try {
      await api.post("/api/cuentas/crear", {
        account_type: "Ahorros",
        currency: "PEN",
      });

      setMessage("Nueva cuenta creada correctamente.");
      await loadDashboard();
    } catch (error) {
      setMessage(error.response?.data?.detail || "No se pudo crear la cuenta.");
    } finally {
      setLoading(false);
    }
  }

  async function makeDeposit(e) {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    try {
      await api.post("/api/ahorros/deposito", {
        account_id: Number(depositForm.account_id),
        amount: Number(depositForm.amount),
        description: depositForm.description,
      });

      setMessage("Deposito realizado correctamente.");
      setDepositForm({ ...depositForm, amount: "" });
      await loadDashboard();
    } catch (error) {
      setMessage(error.response?.data?.detail || "No se pudo realizar el deposito.");
    } finally {
      setLoading(false);
    }
  }

  async function makePayment(e) {
    e.preventDefault();

    const ok = window.confirm("Confirmas el pago del servicio?");
    if (!ok) return;

    setLoading(true);
    setMessage("");

    try {
      await api.post("/api/pagos", {
        account_id: Number(paymentForm.account_id),
        service: paymentForm.service,
        contract_number: paymentForm.contract_number,
        amount: Number(paymentForm.amount),
      });

      setMessage("Pago realizado correctamente.");
      setPaymentForm({ ...paymentForm, amount: "", contract_number: "" });
      await loadDashboard();
    } catch (error) {
      setMessage(error.response?.data?.detail || "No se pudo realizar el pago.");
    } finally {
      setLoading(false);
    }
  }

  async function makeTransfer(e) {
    e.preventDefault();

    const ok = window.confirm("Confirmas la transferencia?");
    if (!ok) return;

    setLoading(true);
    setMessage("");

    try {
      await api.post("/api/transferencias", {
        from_account_id: Number(transferForm.from_account_id),
        to_account_number: transferForm.to_account_number,
        amount: Number(transferForm.amount),
        description: transferForm.description,
      });

      setMessage("Transferencia realizada correctamente.");
      setTransferForm({ ...transferForm, amount: "", to_account_number: "" });
      await loadDashboard();
    } catch (error) {
      setMessage(error.response?.data?.detail || "No se pudo realizar la transferencia.");
    } finally {
      setLoading(false);
    }
  }

  async function requestCredit(e) {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    try {
      await api.post("/api/creditos/solicitar", {
        product: creditForm.product,
        amount: Number(creditForm.amount),
        term_months: Number(creditForm.term_months),
        monthly_income: Number(creditForm.monthly_income),
        purpose: creditForm.purpose,
      });

      setMessage("Solicitud de credito registrada correctamente.");
      setCreditForm({ ...creditForm, amount: "", monthly_income: "", purpose: "" });
      await loadDashboard();
    } catch (error) {
      setMessage(error.response?.data?.detail || "No se pudo registrar el credito.");
    } finally {
      setLoading(false);
    }
  }

  if (!user) {
    return (
      <main className="auth-page">
        <section className="hero">
          <div className="brand">
            <div className="brand-icon">
              <Landmark size={32} />
            </div>
            <div>
              <h1>BanBif</h1>
              <p>Portal bancario seguro, rapido y moderno</p>
            </div>
          </div>

          <div className="hero-card">
            <ShieldCheck size={36} />
            <h2>Banca digital profesional</h2>
            <p>
              Gestiona cuentas, transferencias, pagos y solicitudes de credito
              desde una plataforma conectada a Supabase.
            </p>
          </div>
        </section>

        <section className="auth-card">
          <div className="tabs">
            <button className={mode === "login" ? "active" : ""} onClick={() => setMode("login")}>
              Ingresar
            </button>
            <button className={mode === "register" ? "active" : ""} onClick={() => setMode("register")}>
              Registrarme
            </button>
          </div>

          {mode === "login" ? (
            <form onSubmit={handleLogin} className="form">
              <h2>Inicio de sesion</h2>

              <label>Correo o documento</label>
              <input
                value={loginForm.identifier}
                onChange={(e) => setLoginForm({ ...loginForm, identifier: e.target.value })}
                placeholder="Ej: 99999994"
                required
              />

              <label>Contrasena</label>
              <input
                type="password"
                value={loginForm.password}
                onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                placeholder="Tu contrasena"
                required
              />

              <button className="primary" disabled={loading}>
                {loading ? "Validando..." : "Ingresar"}
              </button>
            </form>
          ) : (
            <form onSubmit={handleRegister} className="form">
              <h2>Crear usuario</h2>

              <label>Nombre completo</label>
              <input
                value={registerForm.name}
                onChange={(e) => setRegisterForm({ ...registerForm, name: e.target.value })}
                required
              />

              <label>Correo</label>
              <input
                type="email"
                value={registerForm.email}
                onChange={(e) => setRegisterForm({ ...registerForm, email: e.target.value })}
                required
              />

              <label>Documento</label>
              <input
                value={registerForm.document}
                onChange={(e) => setRegisterForm({ ...registerForm, document: e.target.value })}
                required
              />

              <label>Contrasena</label>
              <input
                type="password"
                value={registerForm.password}
                onChange={(e) => setRegisterForm({ ...registerForm, password: e.target.value })}
                required
              />

              <button className="primary" disabled={loading}>
                {loading ? "Creando..." : "Crear cuenta"}
              </button>
            </form>
          )}

          {message && <p className="message">{message}</p>}
        </section>
      </main>
    );
  }

  const accounts = dashboard?.accounts || [];
  const movements = dashboard?.last_movements || [];
  const credits = dashboard?.credits || [];
  const payments = dashboard?.payments || [];

  return (
    <main className="app-page">
      <aside className="sidebar">
        <div className="side-brand">
          <Landmark />
          <div>
            <strong>BanBif</strong>
            <span>Banca Digital</span>
          </div>
        </div>

        <nav>
          <a href="#resumen">Resumen</a>
          <a href="#ahorros">Ahorros</a>
          <a href="#pagos">Pagos</a>
          <a href="#transferencias">Transferencias</a>
          <a href="#creditos">Creditos</a>
        </nav>

        <button className="logout" onClick={logout}>
          <LogOut size={18} />
          Salir
        </button>
      </aside>

      <section className="content">
        <header className="topbar">
          <div>
            <p>Bienvenido</p>
            <h1>{user.full_name}</h1>
          </div>

          <button className="ghost" onClick={loadDashboard}>
            <RefreshCcw size={18} />
            Actualizar
          </button>
        </header>

        {message && <div className="toast">{message}</div>}

        <section id="resumen" className="grid cards">
          <article className="metric">
            <Wallet />
            <span>Saldo total</span>
            <strong>{money(dashboard?.total_balance)}</strong>
          </article>

          <article className="metric">
            <CreditCard />
            <span>Cuentas activas</span>
            <strong>{dashboard?.accounts_count || 0}</strong>
          </article>

          <article className="metric">
            <Receipt />
            <span>Pagos registrados</span>
            <strong>{payments.length}</strong>
          </article>

          <article className="metric">
            <PiggyBank />
            <span>Creditos</span>
            <strong>{credits.length}</strong>
          </article>
        </section>

        <section className="panel">
          <div className="panel-head">
            <div>
              <h2>Cuentas bancarias</h2>
              <p>Administra tus cuentas asociadas al portal.</p>
            </div>
            <button className="primary small" onClick={createAccount} disabled={loading}>
              Abrir nueva cuenta
            </button>
          </div>

          <div className="account-list">
            {accounts.map((account) => (
              <div className="account-card" key={account.id}>
                <span>{account.account_type}</span>
                <strong>{account.account_number}</strong>
                <p>{account.currency} Â· {account.status}</p>
                <h3>{money(account.balance)}</h3>
              </div>
            ))}
          </div>
        </section>

        <section id="ahorros" className="panel">
          <h2>Ahorros</h2>
          <form className="module-form" onSubmit={makeDeposit}>
            <select
              value={depositForm.account_id}
              onChange={(e) => setDepositForm({ ...depositForm, account_id: e.target.value })}
              required
            >
              <option value="">Selecciona cuenta</option>
              {accounts.map((account) => (
                <option value={account.id} key={account.id}>
                  {account.account_number} - {money(account.balance)}
                </option>
              ))}
            </select>

            <input
              type="number"
              value={depositForm.amount}
              onChange={(e) => setDepositForm({ ...depositForm, amount: e.target.value })}
              placeholder="Monto"
              required
            />

            <input
              value={depositForm.description}
              onChange={(e) => setDepositForm({ ...depositForm, description: e.target.value })}
              placeholder="Descripcion"
            />

            <button className="primary" disabled={loading}>Depositar</button>
          </form>
        </section>

        <section id="pagos" className="panel">
          <h2>Pagos de servicios</h2>
          <form className="module-form" onSubmit={makePayment}>
            <select
              value={paymentForm.account_id}
              onChange={(e) => setPaymentForm({ ...paymentForm, account_id: e.target.value })}
              required
            >
              <option value="">Cuenta de pago</option>
              {accounts.map((account) => (
                <option value={account.id} key={account.id}>
                  {account.account_number} - {money(account.balance)}
                </option>
              ))}
            </select>

            <select
              value={paymentForm.service}
              onChange={(e) => setPaymentForm({ ...paymentForm, service: e.target.value })}
            >
              <option>Luz</option>
              <option>Agua</option>
              <option>Internet</option>
              <option>Telefonia</option>
            </select>

            <input
              value={paymentForm.contract_number}
              onChange={(e) => setPaymentForm({ ...paymentForm, contract_number: e.target.value })}
              placeholder="Numero de contrato"
              required
            />

            <input
              type="number"
              value={paymentForm.amount}
              onChange={(e) => setPaymentForm({ ...paymentForm, amount: e.target.value })}
              placeholder="Monto"
              required
            />

            <button className="primary" disabled={loading}>Pagar</button>
          </form>
        </section>

        <section id="transferencias" className="panel">
          <h2>Transferencias</h2>
          <form className="module-form" onSubmit={makeTransfer}>
            <select
              value={transferForm.from_account_id}
              onChange={(e) => setTransferForm({ ...transferForm, from_account_id: e.target.value })}
              required
            >
              <option value="">Cuenta origen</option>
              {accounts.map((account) => (
                <option value={account.id} key={account.id}>
                  {account.account_number} - {money(account.balance)}
                </option>
              ))}
            </select>

            <input
              value={transferForm.to_account_number}
              onChange={(e) => setTransferForm({ ...transferForm, to_account_number: e.target.value })}
              placeholder="Cuenta destino"
              required
            />

            <input
              type="number"
              value={transferForm.amount}
              onChange={(e) => setTransferForm({ ...transferForm, amount: e.target.value })}
              placeholder="Monto"
              required
            />

            <button className="primary" disabled={loading}>
              <Send size={17} />
              Transferir
            </button>
          </form>
        </section>

        <section id="creditos" className="panel">
          <h2>Creditos</h2>
          <form className="module-form" onSubmit={requestCredit}>
            <select
              value={creditForm.product}
              onChange={(e) => setCreditForm({ ...creditForm, product: e.target.value })}
            >
              <option>Credito personal</option>
              <option>Credito estudios</option>
              <option>Credito vehicular</option>
              <option>Credito negocio</option>
            </select>

            <input
              type="number"
              value={creditForm.amount}
              onChange={(e) => setCreditForm({ ...creditForm, amount: e.target.value })}
              placeholder="Monto solicitado"
              required
            />

            <input
              type="number"
              value={creditForm.term_months}
              onChange={(e) => setCreditForm({ ...creditForm, term_months: e.target.value })}
              placeholder="Meses"
              required
            />

            <input
              type="number"
              value={creditForm.monthly_income}
              onChange={(e) => setCreditForm({ ...creditForm, monthly_income: e.target.value })}
              placeholder="Ingreso mensual"
              required
            />

            <input
              value={creditForm.purpose}
              onChange={(e) => setCreditForm({ ...creditForm, purpose: e.target.value })}
              placeholder="Proposito"
              required
            />

            <button className="primary" disabled={loading}>Solicitar credito</button>
          </form>
        </section>

        <section className="panel">
          <h2>Ultimos movimientos</h2>
          <div className="table">
            {movements.length === 0 ? (
              <p className="empty">No hay movimientos recientes.</p>
            ) : (
              movements.map((m) => (
                <div className="row" key={m.id}>
                  <div>
                    <strong>{m.description}</strong>
                    <span>{m.operation_type}</span>
                  </div>
                  <b className={Number(m.amount) < 0 ? "negative" : "positive"}>
                    {money(m.amount)}
                  </b>
                </div>
              ))
            )}
          </div>
        </section>

        <section className="panel">
          <h2>Solicitudes de credito</h2>
          <div className="table">
            {credits.length === 0 ? (
              <p className="empty">No tienes solicitudes registradas.</p>
            ) : (
              credits.map((c) => (
                <div className="row" key={c.id}>
                  <div>
                    <strong>{c.product}</strong>
                    <span>{c.months} meses Â· {c.purpose}</span>
                  </div>
                  <b>{c.status}</b>
                </div>
              ))
            )}
          </div>
        </section>
      </section>
    </main>
  );
}
