﻿from pydantic import BaseModel
from decimal import Decimal


class CreateAccountRequest(BaseModel):
    account_type: str = "Ahorros"
    currency: str = "PEN"


class TransferRequest(BaseModel):
    from_account_id: int
    to_account_number: str
    amount: Decimal
    description: str = "Transferencia bancaria"


class CreditRequest(BaseModel):
    product: str = "Credito personal"
    amount: Decimal
    term_months: int
    monthly_income: Decimal
    purpose: str = "Solicitud de credito"


class PaymentRequest(BaseModel):
    account_id: int
    service: str
    contract_number: str
    amount: Decimal

class DepositRequest(BaseModel):
    account_id: int
    amount: Decimal
    description: str = "Deposito de ahorros"
