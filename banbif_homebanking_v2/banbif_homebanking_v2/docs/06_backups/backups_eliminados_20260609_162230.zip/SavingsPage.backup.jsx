import { money, maskAccount } from "../utils/format";

export default function SavingsPage({
  accounts,
  depositForm,
  setDepositForm,
  newAccountForm,
  setNewAccountForm,
  makeDeposit,
  createAccount,
  loading,
  onFeedback,
}) {
  function copyAccount(number) {
    navigator.clipboard?.writeText(number);
    onFeedback("Numero de cuenta copiado.", "success");
  }

  return (
    <section className="page-stack">
      <div className="page-title">
        <span className="section-label">Modulo de ahorros</span>
        <h2>Cuentas, saldos y depositos</h2>
        <p>El cliente puede administrar varias cuentas y abrir nuevas cuentas bajo confirmacion.</p>
      </div>

      <section className="panel">
        <div className="panel-head">
          <div>
            <h2>Mis cuentas</h2>
            <p>Las cuentas se muestran enmascaradas por seguridad visual.</p>
          </div>
        </div>

        <div className="account-list">
          {accounts.map((account) => (
            <div className="account-card" key={account.id}>
              <span>{account.account_type}</span>
              <strong>{maskAccount(account.account_number)}</strong>
              <p>{account.currency} Ãƒâ€šÃ‚Â· {account.status}</p>
              <h3>{money(account.balance)}</h3>
              <button className="card-action" onClick={() => copyAccount(account.account_number)}>
                Copiar numero real
              </button>
            </div>
          ))}
        </div>
      </section>

      <section className="two-columns">
        <article className="panel">
          <h2>Abrir nueva cuenta</h2>
          <p>Simula la aceptacion de condiciones para crear una cuenta adicional.</p>

          <form className="form" onSubmit={createAccount}>
            <label>Tipo de cuenta</label>
            <select
              value={newAccountForm.account_type}
              onChange={(e) => setNewAccountForm({ ...newAccountForm, account_type: e.target.value })}
            >
              <option>Ahorros</option>
              <option>Corriente</option>
              <option>Sueldo</option>
            </select>

            <label>Moneda</label>
            <select
              value={newAccountForm.currency}
              onChange={(e) => setNewAccountForm({ ...newAccountForm, currency: e.target.value })}
            >
              <option value="PEN">Soles - PEN</option>
              <option value="USD">Dolares - USD</option>
            </select>

            <label className="check-line">
              <input
                type="checkbox"
                checked={newAccountForm.accept_terms}
                onChange={(e) => setNewAccountForm({ ...newAccountForm, accept_terms: e.target.checked })}
              />
              Confirmo que deseo abrir una nueva cuenta y acepto condiciones referenciales.
            </label>

            <button className="primary" disabled={loading || !newAccountForm.accept_terms}>
              Abrir cuenta
            </button>
          </form>
        </article>

        <article className="panel">
          <h2>Realizar deposito</h2>
          <form className="form" onSubmit={makeDeposit}>
            <label>Cuenta destino</label>
            <select
              value={depositForm.account_id}
              onChange={(e) => setDepositForm({ ...depositForm, account_id: e.target.value })}
              required
            >
              <option value="">Selecciona cuenta</option>
              {accounts.map((account) => (
                <option value={account.id} key={account.id}>
                  {maskAccount(account.account_number)} - {money(account.balance)}
                </option>
              ))}
            </select>

            <label>Monto</label>
            <input
              type="number"
              value={depositForm.amount}
              onChange={(e) => setDepositForm({ ...depositForm, amount: e.target.value })}
              placeholder="Monto a depositar"
              min="1"
              required
            />

            <label>Descripcion</label>
            <input
              value={depositForm.description}
              onChange={(e) => setDepositForm({ ...depositForm, description: e.target.value })}
              placeholder="Ejemplo: Deposito inicial"
            />

            <button className="primary" disabled={loading}>Depositar</button>
          </form>
        </article>
      </section>
    </section>
  );
}