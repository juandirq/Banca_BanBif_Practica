import { money, maskAccount, formatDate, getAccountById } from "../utils/format";
import { getBalanceAfterOperation, isInsufficientBalance } from "../utils/banking";

export default function PaymentsPage({
  accounts,
  payments,
  paymentForm,
  setPaymentForm,
  makePayment,
  loading,
}) {
  const selectedAccount = getAccountById(accounts, paymentForm.account_id);
  const balanceAfter = getBalanceAfterOperation(selectedAccount?.balance, paymentForm.amount);
  const insufficient = selectedAccount && isInsufficientBalance(selectedAccount.balance, paymentForm.amount);

  return (
    <section className="page-stack">
      <div className="page-title">
        <span className="section-label">Modulo de pagos</span>
        <h2>Pago de servicios</h2>
        <p>Realiza pagos desde una cuenta seleccionada y revisa el saldo antes de confirmar.</p>
      </div>

      <section className="two-columns">
        <article className="panel">
          <h2>Nuevo pago</h2>

          <form className="form" onSubmit={makePayment}>
            <label>Cuenta de cargo</label>
            <select
              value={paymentForm.account_id}
              onChange={(e) => setPaymentForm({ ...paymentForm, account_id: e.target.value })}
              required
            >
              <option value="">Selecciona cuenta</option>
              {accounts.map((account) => (
                <option value={account.id} key={account.id}>
                  {maskAccount(account.account_number)} - {money(account.balance)}
                </option>
              ))}
            </select>

            <label>Servicio</label>
            <select
              value={paymentForm.service}
              onChange={(e) => setPaymentForm({ ...paymentForm, service: e.target.value })}
            >
              <option>Luz</option>
              <option>Agua</option>
              <option>Internet</option>
              <option>Telefonia</option>
            </select>

            <label>Numero de contrato</label>
            <input
              value={paymentForm.contract_number}
              onChange={(e) => setPaymentForm({ ...paymentForm, contract_number: e.target.value })}
              placeholder="Ej: LUZ-2026-001"
              required
            />

            <label>Monto a pagar</label>
            <input
              type="number"
              value={paymentForm.amount}
              onChange={(e) => setPaymentForm({ ...paymentForm, amount: e.target.value })}
              placeholder="Monto"
              min="1"
              required
            />

            <label className="check-line">
              <input
                type="checkbox"
                checked={paymentForm.confirm_payment}
                onChange={(e) => setPaymentForm({ ...paymentForm, confirm_payment: e.target.checked })}
              />
              Confirmo que los datos del pago son correctos.
            </label>

            <button className="primary" disabled={loading || insufficient}>
              Pagar servicio
            </button>
          </form>
        </article>

        <article className="panel">
          <h2>Vista previa del pago</h2>

          {!selectedAccount ? (
            <p className="empty">Selecciona una cuenta para calcular la operacion.</p>
          ) : (
            <div className="preview-box">
              <div>
                <span>Cuenta</span>
                <strong>{maskAccount(selectedAccount.account_number)}</strong>
              </div>
              <div>
                <span>Saldo actual</span>
                <strong>{money(selectedAccount.balance)}</strong>
              </div>
              <div>
                <span>Monto del pago</span>
                <strong className="negative">{money(paymentForm.amount)}</strong>
              </div>
              <div>
                <span>Saldo despues del pago</span>
                <strong className={balanceAfter < 0 ? "negative" : "positive"}>
                  {money(balanceAfter)}
                </strong>
              </div>

              {insufficient && (
                <p className="danger-note">Saldo insuficiente para procesar este pago.</p>
              )}
            </div>
          )}
        </article>
      </section>

      <section className="panel">
        <h2>Pagos recientes</h2>
        <div className="table">
          {payments.length === 0 ? (
            <p className="empty">No tienes pagos registrados.</p>
          ) : (
            payments.map((p) => (
              <div className="row" key={p.id}>
                <div>
                  <strong>{p.servicio}</strong>
                  <span>Contrato {p.numero_contrato} Ã‚Â· {p.estado} Ã‚Â· {formatDate(p.created_at)}</span>
                </div>
                <b className="negative">{money(p.monto)}</b>
              </div>
            ))
          )}
        </div>
      </section>
    </section>
  );
}