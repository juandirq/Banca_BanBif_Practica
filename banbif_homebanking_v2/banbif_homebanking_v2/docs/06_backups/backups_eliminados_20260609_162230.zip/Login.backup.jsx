﻿import { useState } from "react";
import { Building2, LockKeyhole, UserRoundCheck } from "lucide-react";

import { loginAnalyst } from "../services/coreApi";

export default function Login({ onLogin }) {
  const [usuario, setUsuario] = useState("");
  const [clave, setClave] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function ingresar(e) {
    e.preventDefault();

    if (!usuario.trim() || !clave.trim()) {
      setError("Ingresa tu usuario y contraseña interna.");
      return;
    }

    try {
      setLoading(true);
      setError("");

      const data = await loginAnalyst(usuario, clave);

      sessionStorage.setItem("coreAnalyst", JSON.stringify(data.analyst));
      onLogin(data.analyst);
    } catch (err) {
      setError("Credenciales internas incorrectas.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="login-shell">
      <section className="login-card">
        <div className="login-icon">
          <Building2 size={34} />
        </div>

        <p className="eyebrow">Acceso interno</p>
        <h1>Core Financiero BanBif</h1>

        <p className="login-subtitle">
          Plataforma interna para analistas del banco. Permite revisar
          solicitudes de credito, scoring, riesgo y decisiones crediticias.
        </p>

        <form onSubmit={ingresar} className="login-form">
          <label>
            Usuario interno
            <div className="login-input">
              <UserRoundCheck size={18} />
              <input
                value={usuario}
                onChange={(e) => setUsuario(e.target.value)}
                placeholder="Usuario del analista"
                autoComplete="username"
              />
            </div>
          </label>

          <label>
            Contraseña
            <div className="login-input">
              <LockKeyhole size={18} />
              <input
                type="password"
                value={clave}
                onChange={(e) => setClave(e.target.value)}
                placeholder="Contraseña interna"
                autoComplete="current-password"
              />
            </div>
          </label>

          {error && <div className="login-error">{error}</div>}

          <button type="submit" className="login-btn" disabled={loading}>
            {loading ? "Validando acceso..." : "Ingresar al panel interno"}
          </button>
        </form>
      </section>
    </main>
  );
}
