﻿import { useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  Building2,
  CheckCircle,
  ClipboardList,
  Gauge,
  LogOut,
  RefreshCcw,
  Search,
  ShieldCheck,
  UserCheck,
  XCircle
} from "lucide-react";

import { getSolicitudes, tomarDecision } from "../services/coreApi";
import { formatDate, formatMoney } from "../utils/format";
import StatCard from "../components/StatCard";
import RiskBadge from "../components/RiskBadge";
import StatusBadge from "../components/StatusBadge";

function normalize(value) {
  return String(value || "").toLowerCase();
}

function isFinalStatus(status) {
  const value = normalize(status);
  return value.includes("aprobado") || value.includes("rechazado");
}

function getRatioCuota(solicitud) {
  const monto = Number(solicitud?.amount || 0);
  const meses = Number(solicitud?.months || 0);
  const ingreso = Number(solicitud?.monthly_income || 0);

  if (!monto || !meses || !ingreso) return 0;

  const cuota = monto / meses;
  return cuota / ingreso;
}

export default function Dashboard({ analyst, onLogout }) {
  const [solicitudes, setSolicitudes] = useState([]);
  const [selected, setSelected] = useState(null);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");
  const [estadoFiltro, setEstadoFiltro] = useState("todos");
  const [search, setSearch] = useState("");

  async function cargarSolicitudes() {
    try {
      setLoading(true);
      setMessage("");

      const data = await getSolicitudes();
      const lista = data.solicitudes || [];

      setSolicitudes(lista);

      if (!selected && lista.length > 0) {
        setSelected(lista[0]);
      }
    } catch (error) {
      setMessage("No se pudo conectar con el core financiero backend.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    cargarSolicitudes();
  }, []);

  const resumen = useMemo(() => {
    const total = solicitudes.length;
    const evaluacion = solicitudes.filter((s) =>
      normalize(s.status).includes("evaluacion")
    ).length;
    const aprobadas = solicitudes.filter((s) =>
      normalize(s.status).includes("aprobado")
    ).length;
    const rechazadas = solicitudes.filter((s) =>
      normalize(s.status).includes("rechazado")
    ).length;

    const riesgoAlto = solicitudes.filter((s) =>
      normalize(s.scoring?.riesgo).includes("alto")
    ).length;

    return { total, evaluacion, aprobadas, rechazadas, riesgoAlto };
  }, [solicitudes]);

  const filtradas = useMemo(() => {
    return solicitudes.filter((s) => {
      const estado = normalize(s.status);
      const texto = `${s.id} ${s.user_id} ${s.product} ${s.purpose} ${s.status}`.toLowerCase();

      const cumpleBusqueda = texto.includes(search.toLowerCase());

      const cumpleEstado =
        estadoFiltro === "todos" ||
        (estadoFiltro === "evaluacion" && estado.includes("evaluacion")) ||
        (estadoFiltro === "aprobado" && estado.includes("aprobado")) ||
        (estadoFiltro === "rechazado" && estado.includes("rechazado"));

      return cumpleBusqueda && cumpleEstado;
    });
  }, [solicitudes, search, estadoFiltro]);

  async function decidir(solicitud, decision) {
    const textoDecision = decision === "aprobado" ? "aprobar" : "rechazar";

    const ok = window.confirm(
      `Confirmas ${textoDecision} la solicitud #${solicitud.id}?`
    );

    if (!ok) return;

    const observacion =
      decision === "aprobado"
        ? "Cliente con capacidad de pago favorable segun scoring interno."
        : "Solicitud rechazada por riesgo crediticio alto segun scoring interno.";

    try {
      const data = await tomarDecision(solicitud.id, decision, observacion, analyst);

      setMessage(data.mensaje || "Decision registrada correctamente.");
      setSelected(data.solicitud);

      const actualizadas = await getSolicitudes();
      setSolicitudes(actualizadas.solicitudes || []);
    } catch (error) {
      setMessage("No se pudo registrar la decision.");
    }
  }

  const ratioCuota = getRatioCuota(selected);
  const cuotaAprox =
    selected?.amount && selected?.months
      ? Number(selected.amount) / Number(selected.months)
      : 0;

  return (
    <main className="core-shell">
      <section className="hero">
        <div className="hero-left">
          <div className="brand-mark">
            <Building2 size={28} />
          </div>

          <div>
            <p className="eyebrow">Core financiero interno</p>
            <h1>Panel de Analista BanBif</h1>
            <p>
              Bandeja interna para evaluar solicitudes de credito, revisar scoring,
              analizar riesgo y registrar decisiones.
            </p>
          </div>
        </div>

        <div className="hero-actions">
          <div className="connection-pill">
            <span></span>
            Sistema conectado
          </div>

          <div className="analyst-pill">
            {analyst?.full_name || "Analista"}
          </div>

          <button className="refresh-btn" onClick={cargarSolicitudes}>
            <RefreshCcw size={18} />
            Actualizar
          </button>

          <button className="logout-btn" onClick={onLogout}>
            <LogOut size={18} />
            Salir
          </button>
        </div>
      </section>

      {message && <div className="notice">{message}</div>}

      <section className="stats-grid">
        <StatCard title="Solicitudes" value={resumen.total} subtitle="Total registradas" />
        <StatCard title="En evaluacion" value={resumen.evaluacion} subtitle="Pendientes de decision" />
        <StatCard title="Aprobadas" value={resumen.aprobadas} subtitle="Decision favorable" />
        <StatCard title="Riesgo alto" value={resumen.riesgoAlto} subtitle="Casos criticos" />
      </section>

      <section className="toolbar">
        <div className="search-box">
          <Search size={18} />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar por ID, producto, cliente o proposito..."
          />
        </div>

        <div className="filter-tabs">
          <button
            className={estadoFiltro === "todos" ? "active-filter" : ""}
            onClick={() => setEstadoFiltro("todos")}
          >
            Todos
          </button>

          <button
            className={estadoFiltro === "evaluacion" ? "active-filter" : ""}
            onClick={() => setEstadoFiltro("evaluacion")}
          >
            En evaluacion
          </button>

          <button
            className={estadoFiltro === "aprobado" ? "active-filter" : ""}
            onClick={() => setEstadoFiltro("aprobado")}
          >
            Aprobados
          </button>

          <button
            className={estadoFiltro === "rechazado" ? "active-filter" : ""}
            onClick={() => setEstadoFiltro("rechazado")}
          >
            Rechazados
          </button>
        </div>
      </section>

      <section className="content-grid">
        <div className="panel">
          <div className="panel-header">
            <div>
              <h2>Bandeja de creditos</h2>
              <p>Solicitudes recibidas desde el portal cliente.</p>
            </div>

            <div className="panel-counter">
              <ClipboardList size={18} />
              {filtradas.length} visibles
            </div>
          </div>

          {loading ? (
            <div className="empty">Cargando solicitudes...</div>
          ) : filtradas.length === 0 ? (
            <div className="empty">No hay solicitudes con ese filtro.</div>
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Cliente</th>
                    <th>Producto</th>
                    <th>Monto</th>
                    <th>Ingreso</th>
                    <th>Score</th>
                    <th>Riesgo</th>
                    <th>Estado</th>
                  </tr>
                </thead>

                <tbody>
                  {filtradas.map((solicitud) => (
                    <tr
                      key={solicitud.id}
                      onClick={() => setSelected(solicitud)}
                      className={selected?.id === solicitud.id ? "active-row" : ""}
                    >
                      <td>#{solicitud.id}</td>
                      <td>Usuario {solicitud.user_id}</td>
                      <td>{solicitud.product}</td>
                      <td>{formatMoney(solicitud.amount)}</td>
                      <td>{formatMoney(solicitud.monthly_income)}</td>
                      <td>
                        <strong>{solicitud.scoring?.score ?? "-"}</strong>
                      </td>
                      <td>
                        <RiskBadge risk={solicitud.scoring?.riesgo} />
                      </td>
                      <td>
                        <StatusBadge status={solicitud.status} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <aside className="detail-card">
          {selected ? (
            <>
              <div className="detail-top">
                <div>
                  <p className="eyebrow">Solicitud #{selected.id}</p>
                  <h2>{selected.product}</h2>
                  <small>Usuario {selected.user_id}</small>
                </div>

                <StatusBadge status={selected.status} />
              </div>

              <div className="score-box">
                <ShieldCheck size={28} />

                <div>
                  <span>Score crediticio</span>
                  <strong>{selected.scoring?.score ?? "-"}/100</strong>
                </div>

                <RiskBadge risk={selected.scoring?.riesgo} />
              </div>

              <div className="analysis-grid">
                <div className="analysis-card">
                  <Gauge size={18} />
                  <span>Cuota aprox.</span>
                  <strong>{formatMoney(cuotaAprox)}</strong>
                </div>

                <div className="analysis-card">
                  <UserCheck size={18} />
                  <span>Cuota / ingreso</span>
                  <strong>{Math.round(ratioCuota * 100)}%</strong>
                </div>
              </div>

              <div className="info-grid">
                <div>
                  <span>Monto solicitado</span>
                  <strong>{formatMoney(selected.amount)}</strong>
                </div>

                <div>
                  <span>Ingreso mensual</span>
                  <strong>{formatMoney(selected.monthly_income)}</strong>
                </div>

                <div>
                  <span>Plazo</span>
                  <strong>{selected.months} meses</strong>
                </div>

                <div>
                  <span>Fecha</span>
                  <strong>{formatDate(selected.created_at)}</strong>
                </div>
              </div>

              <div className="purpose">
                <span>Proposito declarado</span>
                <p>{selected.purpose || "Sin detalle"}</p>
              </div>

              <div className="factors">
                <span>Factores evaluados por el scoring</span>

                <ul>
                  {(selected.scoring?.factores || []).map((factor, index) => (
                    <li key={index}>{factor}</li>
                  ))}
                </ul>
              </div>

              <div className="comment-box">
                <span>Comentario del analista</span>
                <p>{selected.analyst_comment || "Sin comentario registrado."}</p>
              </div>

              <div className="recommendation">
                {selected.scoring?.recomendacion === "APROBAR" ? (
                  <CheckCircle size={20} />
                ) : (
                  <AlertTriangle size={20} />
                )}

                Recomendacion del sistema:
                <strong>{selected.scoring?.recomendacion}</strong>
              </div>

              {isFinalStatus(selected.status) ? (
                <div className="locked-decision">
                  Esta solicitud ya tiene decision registrada.
                </div>
              ) : (
                <div className="action-row">
                  <button
                    className="approve-btn"
                    onClick={() => decidir(selected, "aprobado")}
                  >
                    <CheckCircle size={18} />
                    Aprobar
                  </button>

                  <button
                    className="reject-btn"
                    onClick={() => decidir(selected, "rechazado")}
                  >
                    <XCircle size={18} />
                    Rechazar
                  </button>
                </div>
              )}
            </>
          ) : (
            <div className="empty">Selecciona una solicitud.</div>
          )}
        </aside>
      </section>

      <footer className="core-footer">
        <span>Core Financiero BanBif</span>
        <span>Panel interno de analista</span>
        <span>Motor de scoring crediticio</span>
        <span>Supabase PostgreSQL</span>
      </footer>
    </main>
  );
}




