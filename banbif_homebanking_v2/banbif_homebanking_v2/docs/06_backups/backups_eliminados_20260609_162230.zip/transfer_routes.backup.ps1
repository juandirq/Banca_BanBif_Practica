﻿from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.routes.auth_routes import get_current_user_id
from app.schemas.banking_schema import TransferRequest
from app.services.banking_service import make_transfer

router = APIRouter(prefix="/api/transferencias", tags=["Transferencias"])


@router.post("")
def transfer(
    payload: TransferRequest,
    db: Session = Depends(get_db),
    user_id: int = Depends(get_current_user_id),
):
    return make_transfer(
        db,
        user_id,
        payload.from_account_id,
        payload.to_account_number,
        payload.amount,
        payload.description,
    )
