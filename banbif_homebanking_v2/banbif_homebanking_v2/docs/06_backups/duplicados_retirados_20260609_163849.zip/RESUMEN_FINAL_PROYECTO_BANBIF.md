﻿# RESUMEN FINAL DEL PROYECTO BANBIF HOMEBANKING

## 1. Objetivo del sistema

El proyecto simula un ecosistema bancario dividido en dos partes:

- Portal cliente BanBif Homebanking.
- Core financiero interno para analistas, riesgos, comite, gerencia, agencia y administrador.

La logica de negocio principal se encuentra en backend. El frontend se usa como capa de presentacion, formularios, validaciones visuales y experiencia de usuario.

---

## 2. Modulos del cliente

### Autenticacion
- Registro de cliente.
- Login con token.
- Rutas protegidas por autenticacion.

### Dashboard cliente
- Consulta de cuentas.
- Movimientos.
- Resumen financiero.
- Notificaciones.

### Ahorros
- Apertura de Cuenta Ahorro Digital.
- Cuenta Sueldo y Cuenta Corriente no se abren libremente desde la demo.
- Depositos en cuenta propia.

### Pagos
- Pago de servicios.
- Pago de prestamo.
- Pago de tarjeta de credito BanBif ya existente.
- Token Digital obligatorio.
- Saldo suficiente obligatorio.
- Pago minimo referencial de tarjeta: S/ 30.00.

### Transferencias
- Transferencia a cuenta BanBif.
- Token Digital obligatorio.
- Validacion de saldo suficiente.
- Limite por operacion referencial.

### PLIN interoperable
- Transferencia por celular.
- Celular peruano valido: 9 digitos e inicia con 9.
- Minimo: S/ 1.00.
- Maximo por operacion: S/ 500.00.
- Maximo diario referencial: S/ 2,000.00.
- Solo cuentas en soles.

### Creditos
- Prestamo Efectivo BanBif.
- Credito Vehicular BanBif.
- Simulacion referencial de cuota.
- Validacion de ingreso minimo.
- Validacion de antiguedad laboral.
- Validacion de estado civil y documentacion del conyuge.
- Evaluacion de centrales de riesgo queda como validacion interna del banco.
- Prestamo Efectivo ejemplo: S/ 5,000 a 12 meses con cuota estimada S/ 585.08.

---

## 3. Core financiero interno

### Roles internos

- ADMIN: supervision general, solo lectura operativa.
- ANALISTA_N1: evalua casos simples asignados.
- ANALISTA_N2: evalua casos de mayor monto o complejidad.
- ANALISTA_N3/N4: evalua casos superiores.
- RIESGOS: gestiona recuperaciones, mora, castigo o judicializacion.
- COMITE: revisa casos fuertes o derivados.
- GERENCIA: revisa casos de alto impacto.
- ADMIN_AGENCIA: ejecuta desembolsos cuando corresponde.

### Reglas principales

- ADMIN no aprueba creditos.
- ADMIN no desembolsa.
- ADMIN no gestiona recuperaciones.
- ADMIN_AGENCIA consulta y desembolsa, pero no decide creditos.
- RIESGOS gestiona recuperaciones.
- Analistas evaluan segun nivel y asignacion.
- Comite y Gerencia revisan casos fuertes.

---

## 4. Power BI

Vistas listas para dashboard:

- cuentas
- transacciones
- solicitudes_prestamo
- vw_pbi_operaciones_banbif
- vw_pbi_resumen_general
- vw_pbi_clientes

Estas vistas permiten analizar:

- saldos por cliente
- transacciones
- pagos
- creditos
- desembolsos
- clientes
- casos de mora
- operaciones por modulo
- evolucion mensual

---

## 5. Estado final de pruebas

Pruebas realizadas por PowerShell:

- Compilacion backend cliente.
- Compilacion backend core.
- Build frontend cliente.
- Build frontend core.
- Login roles internos.
- Permisos de decision crediticia.
- Permisos de desembolso.
- Permisos de recuperaciones.
- Vistas Power BI.
- Registro cliente.
- Apertura Cuenta Ahorro Digital.
- Deposito.
- Pago servicio.
- Pago tarjeta bloqueado menor a S/ 30.
- Transferencia normal.
- PLIN interoperable corregido.
- Credito Prestamo Efectivo.
- Credito Vehicular bloqueado por monto minimo.

Resultado final: proyecto funcional, limpio y listo para revision academica.
