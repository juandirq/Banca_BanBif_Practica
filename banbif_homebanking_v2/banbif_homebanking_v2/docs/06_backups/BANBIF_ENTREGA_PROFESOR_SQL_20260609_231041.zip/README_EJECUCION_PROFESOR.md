﻿# EJECUCION COMPLETA - BANBIF HOMEBANKING + CORE FINANCIERO

Este paquete permite crear la base de datos desde cero y cargar todos los datos del proyecto.

## Base creada

bd_core_financiero

## Forma recomendada

Abrir PowerShell en esta carpeta y ejecutar:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\EJECUTAR_TODO_PROFESOR.ps1

cd C:\Users\Lenovo\Desktop\banbif_homebanking_v2

$root = "C:\Users\Lenovo\Desktop\banbif_homebanking_v2"
$pkg = "$root\sql\entrega_profesor"
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"

New-Item -ItemType Directory -Force -Path $pkg | Out-Null
New-Item -ItemType Directory -Force -Path "$root\docs\07_scripts_sql\entrega_profesor" | Out-Null

@'
# EJECUCION COMPLETA - BANBIF HOMEBANKING + CORE FINANCIERO

Este paquete permite crear la base de datos desde cero y cargar todos los datos del proyecto.

BASE DE DATOS:
bd_core_financiero

FORMA DE EJECUCION:

1. Abrir PowerShell dentro de esta carpeta:
   sql\entrega_profesor

2. Ejecutar:
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

3. Luego ejecutar:
   .\EJECUTAR_TODO_PROFESOR.ps1

4. El script pedira la password del usuario PostgreSQL postgres.

QUE HACE EL SCRIPT:

1. Se conecta a la base postgres.
2. Elimina bd_core_financiero si existe.
3. Crea bd_core_financiero.
4. Crea tablas.
5. Inserta roles, usuarios Core, clientes, cuentas, movimientos, pagos, creditos, desembolsos, mora y recuperaciones.
6. Crea vistas para Power BI.
7. Ejecuta una validacion final.

ARCHIVOS DEL PAQUETE:

- 00_CREAR_BASE_DATOS.sql
  Crea la base de datos bd_core_financiero.

- 01_TODO_SCHEMA_Y_DATOS.sql
  Crea la estructura e inserta datos.

- 02_VALIDACION_FINAL_PROFESOR.sql
  Valida conteos, cartera, mora, creditos, desembolsos, recuperaciones, roles y vistas.

- EJECUTAR_TODO_PROFESOR.ps1
  Ejecuta todo automaticamente desde PowerShell.

USUARIOS DE PRUEBA:

Homebanking:
- 74851263 / 123456
- 81000001 / 123456
- 81000021 / 123456
- 81000045 / 123456

Core Financiero:
- maria.n1 / 123456
- carlos.n2 / 123456
- valeria.n3 / 123456
- jorge.riesgos / 123456
- agencia.admin / 123456
- comite.creditos / 123456
- gerencia.finanzas / 123456
- juan.admin / 123456

NOTA:
Los datos son sinteticos y academicos. No corresponden a personas reales.
