﻿# Estructura del Proyecto BanBif

## Portal cliente

### portal-banbif-frontend
Frontend del cliente bancario.
Permite registro, login, dashboard, ahorros, pagos, transferencias, creditos y perfil.
Puerto: 5173

### portal-banbif-backend
Backend del portal cliente.
Gestiona autenticacion, cuentas, movimientos, pagos, transferencias y solicitudes de credito.
Puerto: 8000

## Core financiero interno

### core-financiero-backend
Backend interno del banco.
Gestiona login de analista, lectura de solicitudes de credito, scoring, riesgo y decision crediticia.
Puerto: 8001

### core-financiero-frontend
Panel interno del analista.
Permite iniciar sesion, revisar solicitudes, ver scoring, aprobar o rechazar creditos.
Puerto: 5174

## Base de datos

Supabase PostgreSQL.
Tablas principales:
- user
- account
- movement
- creditapplication
- pagos
- core_analyst_user

## Reportes

La carpeta sql se usara para vistas SQL y consultas para Power BI.
La carpeta docs contiene documentacion y comandos de ejecucion.
La carpeta backups contiene respaldos del proyecto.
