﻿# Proyecto Integrado BanBif Homebanking + Core Financiero

## Estructura de entrega

Este proyecto integra dos sistemas conectados a una misma base de datos PostgreSQL:

1. Homebanking cliente
   - Solicitud de creditos
   - Consulta de saldo
   - Movimientos
   - Prestamos y desembolsos

2. Core Financiero interno
   - Bandeja de solicitudes
   - Evaluacion crediticia
   - Scoring, RDS y semaforo
   - Comite de creditos
   - Desembolsos
   - Recuperaciones y mora
   - Seguridad JWT + RBAC

## Carpetas principales

- portal-banbif-frontend: frontend del Homebanking.
- portal-banbif-backend: backend del Homebanking.
- core-financiero-frontend: frontend del Core Financiero.
- core-financiero-backend: backend del Core Financiero.
- sql: scripts SQL del proyecto.
- docs: documentacion, diagramas, evidencias y mapeo de rubrica.

## Documentacion incluida

- 01_rubrica: mapeo del proyecto contra la rubrica.
- 02_historias_requisitos: historias de usuario y requisitos funcionales.
- 03_reglas_negocio: reglas de credito, mora y seguridad.
- 04_arquitectura_uml: referencia a diagramas PlantUML.
- 05_pruebas_evidencias: pruebas funcionales y evidencias.
- 06_sql_powerbi: scripts SQL y vistas para Power BI.
- uml: diagramas PlantUML editables.
- out/uml: imagenes exportadas de los diagramas.

## Estado actual

El sistema cuenta con integracion Core - Homebanking, reglas de credito, scoring, desembolso, mora, recuperaciones, JWT, RBAC y vistas para reportes.
