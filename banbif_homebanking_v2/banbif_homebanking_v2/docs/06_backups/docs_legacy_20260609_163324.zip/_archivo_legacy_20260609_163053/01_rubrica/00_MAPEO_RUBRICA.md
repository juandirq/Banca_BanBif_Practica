﻿# Mapeo de rubrica - Proyecto BanBif Homebanking + Core Financiero

## C1. Integracion Core - Homebanking
Evidencia:
- Cliente solicita credito desde Homebanking.
- La solicitud aparece en Core Financiero.
- El analista evalua, aprueba o deriva a comite.
- El desembolso actualiza saldo y movimientos del cliente.

Archivos/modulos:
- portal-banbif-frontend
- portal-banbif-backend
- core-financiero-frontend
- core-financiero-backend
- Tablas: user, account, movement, creditapplication.

## C2. Reglas de negocio del credito
Evidencia:
- Score crediticio.
- RDS cuota / ingreso.
- Semaforo bajo, medio, alto.
- Ruta por monto y riesgo: analista, riesgos o comite.
- Desembolso solo si el credito esta aprobado.

## C3. Seguridad RBAC + JWT
Evidencia:
- Login interno genera token JWT.
- Rutas internas requieren Bearer Token.
- Acciones criticas bloqueadas por rol.
- Ejemplo: admin_agencia no puede castigar y recibe 403.

## C4. Recuperaciones y mora
Evidencia:
- R1: consulta por bandas de mora.
- R2: registro e historial de gestiones.
- R3: judicial desde 121 dias y castigo mayor a 180 dias.

## C5. Calidad de datos y documentacion
Evidencia:
- Modelo de datos documentado.
- Diagramas PlantUML.
- Historias de usuario.
- Requisitos funcionales.
- Scripts SQL.
- Vistas para Power BI.
