﻿# Estructura tecnica de modulos

## 1. Homebanking Cliente - Frontend

Carpeta:

portal-banbif-frontend

Funcion:
Interfaz usada por el cliente para ingresar al banco, consultar saldo, revisar movimientos, solicitar creditos, ver prestamos, realizar pagos y visualizar desembolsos.

Responsabilidades:
- Login y registro de cliente.
- Dashboard del cliente.
- Solicitud de credito.
- Consulta de cuentas y saldo.
- Consulta de movimientos.
- Visualizacion de prestamos.
- Pagos y operaciones basicas.

Puerto local:
http://127.0.0.1:5173

Tecnologia:
React + Vite.

## 2. Homebanking Cliente - Backend

Carpeta:

portal-banbif-backend

Funcion:
API del cliente. Atiende las operaciones del Homebanking y se conecta a PostgreSQL para leer usuarios, cuentas, movimientos, pagos y creditos.

Responsabilidades:
- Autenticacion del cliente.
- Registro de usuarios.
- Consulta de dashboard.
- Registro de solicitudes de credito.
- Consulta de movimientos.
- Consulta de prestamos/desembolsos.
- Operaciones de pagos, ahorros y transferencias.

Puerto local:
http://127.0.0.1:8000

Tecnologia:
FastAPI + PostgreSQL.

## 3. Core Financiero - Frontend

Carpeta:

core-financiero-frontend

Funcion:
Interfaz interna del banco usada por analistas, riesgos, comite, gerencia o administracion para evaluar solicitudes y gestionar cartera.

Responsabilidades:
- Login interno.
- Inicio con indicadores de cartera.
- Bandeja de solicitudes.
- Evaluacion crediticia.
- Comite de creditos.
- Desembolsos.
- Recuperaciones y mora.
- Control de autonomia.

Puerto local:
http://127.0.0.1:5174

Tecnologia:
React + Vite.

## 4. Core Financiero - Backend

Carpeta:

core-financiero-backend

Funcion:
API interna del banco. Implementa reglas de negocio crediticio, scoring, RDS, semaforo, rutas de aprobacion, desembolsos, recuperaciones, JWT y RBAC.

Responsabilidades:
- Login de usuarios internos.
- Generacion y validacion de JWT.
- Control de acceso RBAC.
- Listado de solicitudes.
- Calculo de scoring y RDS.
- Registro de decisiones.
- Derivacion a comite.
- Ejecucion de desembolsos.
- Gestion de recuperaciones y mora.
- Bloqueo de acciones criticas por rol.

Puerto local:
http://127.0.0.1:8001

Tecnologia:
FastAPI + PostgreSQL.

## 5. Base de datos compartida

Nombre:
bd_core_financiero

Motor:
PostgreSQL

Uso:
Ambos sistemas comparten la misma base de datos. Esto permite que una solicitud creada por el cliente en Homebanking aparezca en el Core y que un desembolso realizado en Core se refleje en saldo y movimientos del cliente.

Tablas principales:
- user
- account
- movement
- creditapplication
- core_analyst_user
- recovery_case
- recovery_action
- loan_schedule

## 6. Flujo integrado principal

1. Cliente solicita credito desde Homebanking.
2. El backend cliente registra la solicitud en creditapplication.
3. El Core Financiero consulta la misma tabla.
4. El analista revisa score, RDS, semaforo y ruta.
5. El Core aprueba, rechaza o deriva a comite.
6. Si se aprueba, el Core desembolsa.
7. El desembolso crea un movimiento bancario.
8. Homebanking muestra el nuevo saldo y movimiento al cliente.

## 7. Relacion con la rubrica

- Integracion Core - Homebanking: cubierta por base de datos compartida y flujo de desembolso.
- Reglas de credito: cubiertas por scoring, RDS, semaforo y rutas.
- Seguridad: cubierta por JWT y RBAC.
- Recuperaciones: cubierta por bandas, gestiones, judicial y castigo.
- Documentacion: cubierta por docs, UML, historias, requisitos, SQL y evidencias.
