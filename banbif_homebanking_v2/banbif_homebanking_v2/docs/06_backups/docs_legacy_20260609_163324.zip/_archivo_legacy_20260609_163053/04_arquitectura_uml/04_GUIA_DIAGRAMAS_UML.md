﻿# Diagramas PlantUML del proyecto

Los diagramas editables estan en:

docs/uml

Los diagramas exportados en PNG deben guardarse en:

docs/out/uml

## Diagramas incluidos

1. 01_casos_de_uso.puml
   - Actores principales y casos de uso.

2. 02_secuencia_otorgamiento.puml
   - Flujo de solicitud, evaluacion, decision y desembolso.

3. 03_recuperaciones_estados.puml
   - Estados de mora, judicial y castigo.

4. 04_componentes_ecosistema.puml
   - Componentes frontend, backend, seguridad, reglas y base de datos.

5. 05_modelo_datos_core.puml
   - Modelo de datos principal.

6. 06_actividad_otorgamiento.puml
   - Proceso de otorgamiento crediticio.

7. 07_estados_solicitud.puml
   - Estados de la solicitud de credito.

8. 08_secuencia_recuperaciones.puml
   - Flujo de recuperaciones y gestiones.

9. 09_arquitectura_capas.puml
   - Arquitectura por capas.

## Como exportar

En VS Code:

1. Abrir un archivo .puml.
2. Presionar Alt + D para previsualizar.
3. Ctrl + Shift + P.
4. PlantUML: Export Current File Diagrams.
5. Elegir PNG.
