﻿# Reglas de negocio del Core Financiero

## 1. Evaluacion crediticia

La solicitud registrada por el cliente se evalua en el Core Financiero con los siguientes criterios:

- Producto solicitado.
- Monto solicitado.
- Plazo en meses.
- Ingreso mensual declarado.
- Cuota estimada.
- RDS: relacion cuota / ingreso.
- Score crediticio.
- Nivel de riesgo.
- Semaforo crediticio.
- Ruta de aprobacion.

## 2. RDS

El RDS mide que porcentaje del ingreso mensual representa la cuota estimada del credito.

- RDS bajo: mayor capacidad de pago.
- RDS medio: requiere revision.
- RDS alto: puede derivarse a riesgos o comite.

## 3. Scoring y semaforo

El sistema genera un score referencial y un semaforo:

- Verde: riesgo bajo.
- Amarillo: riesgo medio.
- Rojo: riesgo alto.

Esta regla permite priorizar solicitudes y decidir si el caso puede ser aprobado por analista o debe escalarse.

## 4. Autonomia y rutas

Las solicitudes se derivan segun monto, riesgo y nivel requerido:

- Analista N1, N2, N3 o N4 segun autonomia.
- Riesgos para casos de mayor exposicion.
- Comite de Creditos para decisiones colegiadas.
- Gerencia/Admin para acciones criticas.

## 5. Decision crediticia

El Core permite registrar:

- Aprobado.
- Rechazado.
- En evaluacion.
- En comite.

Cada decision queda asociada a observacion y usuario interno.

## 6. Desembolso

El desembolso solo se ejecuta si la solicitud esta aprobada.

Al desembolsar:

- Se actualiza el estado de desembolso.
- Se crea movimiento tipo DESEMBOLSO_CREDITO.
- Se actualiza el saldo del cliente.
- El cambio se refleja en Homebanking.

## 7. Recuperaciones y mora

La mora se organiza por bandas:

- Preventiva.
- Temprana.
- Tardia.
- Judicial.
- Castigo.

Reglas principales:

- R1: consulta de cartera por bandas.
- R2: registro e historial de gestiones.
- R3: judicial desde 121 dias y castigo mayor a 180 dias.

## 8. Seguridad RBAC + JWT

El Core usa autenticacion JWT y control de acceso por roles.

Ejemplos:

- Sin token: 401.
- Rol sin permiso: 403.
- Admin/Gerencia/Riesgos/Comite: acciones criticas segun permiso.
- Admin agencia: usuario autenticado, pero bloqueado en castigo y acciones criticas.
