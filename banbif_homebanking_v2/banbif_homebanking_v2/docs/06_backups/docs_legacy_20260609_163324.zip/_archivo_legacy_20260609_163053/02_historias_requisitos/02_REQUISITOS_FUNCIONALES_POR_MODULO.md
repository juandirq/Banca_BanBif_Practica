﻿# Requisitos funcionales por modulo

## A. Homebanking Cliente

### RF-C01 Login de cliente
El sistema debe permitir que el cliente ingrese con sus credenciales y acceda a su panel bancario.

### RF-C02 Registro de cliente
El sistema debe permitir registrar nuevos clientes con sus datos basicos.

### RF-C03 Consulta de dashboard
El cliente debe visualizar saldo, cuentas, movimientos, pagos y resumen de creditos.

### RF-C04 Solicitud de credito
El cliente debe poder solicitar un credito indicando producto, monto, plazo e ingreso mensual.

### RF-C05 Seguimiento de credito
El cliente debe poder visualizar el estado de sus creditos: en evaluacion, aprobado, rechazado, en comite o desembolsado.

### RF-C06 Visualizacion de desembolso
Cuando el Core ejecute un desembolso, el cliente debe visualizar el movimiento en su Homebanking.

### RF-C07 Pagos y operaciones
El cliente debe poder realizar pagos o movimientos basicos desde el portal.

## B. Core Financiero

### RF-I01 Login interno
El personal interno debe autenticarse con usuario y contrasena.

### RF-I02 Seguridad JWT
Las rutas internas deben requerir token Bearer.

### RF-I03 RBAC por roles
El sistema debe bloquear acciones no autorizadas segun rol.

### RF-I04 Bandeja de solicitudes
El Core debe listar solicitudes generadas desde Homebanking.

### RF-I05 Evaluacion crediticia
El Core debe mostrar score, RDS, semaforo, riesgo y ruta de aprobacion.

### RF-I06 Decision crediticia
El analista autorizado debe poder aprobar, rechazar, mantener en evaluacion o derivar a comite.

### RF-I07 Comite de creditos
El sistema debe permitir identificar solicitudes que requieren decision colegiada.

### RF-I08 Desembolso
El Core debe permitir desembolsar solo solicitudes aprobadas.

### RF-I09 Recuperaciones R1
El Core debe consultar cartera morosa por bandas.

### RF-I10 Recuperaciones R2
El Core debe registrar e historizar gestiones de cobranza.

### RF-I11 Recuperaciones R3
El Core debe permitir judicializar casos desde 121 dias y proponer castigo mayor a 180 dias.

### RF-I12 Autonomia
El sistema debe mostrar el nivel, rol y capacidad de aprobacion del usuario interno.

## C. Reporteria y Power BI

### RF-R01 Vistas para Power BI
La base de datos debe exponer vistas para operaciones, clientes, creditos, mora y resumen general.

### RF-R02 Dashboard gerencial
El dashboard debe mostrar indicadores como cartera, desembolsos, mora, creditos, clientes y recuperaciones.
