﻿# Historias de usuario y requisitos funcionales

## HU-01 Solicitar credito desde Homebanking
Como cliente, quiero solicitar un credito desde el portal, para que el banco evalue mi solicitud.

RF:
- Registrar monto, producto, plazo e ingreso mensual.
- Guardar la solicitud en creditapplication.
- Mostrar estado inicial en evaluacion.

## HU-02 Evaluar solicitud en Core
Como analista, quiero ver las solicitudes registradas, para evaluar riesgo, score y capacidad de pago.

RF:
- Listar solicitudes en bandeja.
- Mostrar score, RDS, semaforo y ruta responsable.
- Permitir aprobacion, rechazo o derivacion a comite segun reglas.

## HU-03 Controlar autonomia crediticia
Como sistema, quiero validar el nivel y monto maximo del analista, para evitar aprobaciones fuera de autonomia.

RF:
- Validar approval_level.
- Validar max_approval_amount.
- Derivar a comite si supera nivel o riesgo.

## HU-04 Desembolsar credito aprobado
Como area operativa, quiero desembolsar solo creditos aprobados, para impactar saldo y movimientos del cliente.

RF:
- Bloquear desembolso si no esta aprobado.
- Crear movimiento tipo DESEMBOLSO_CREDITO.
- Actualizar saldo de cuenta.
- Marcar credito como desembolsado.

## HU-05 Consultar mora
Como gestor de cobranza, quiero consultar creditos por banda de mora, para priorizar recuperaciones.

RF:
- Mostrar casos preventivos, tempranos, tardios, judiciales y castigo.
- Filtrar por banda y fechas.
- Mostrar saldo vencido y dias de mora.

## HU-06 Registrar gestion de cobranza
Como gestor, quiero registrar acciones de cobranza, para dejar historial del seguimiento.

RF:
- Registrar tipo de accion, comentario y resultado.
- Mostrar historial por caso.
- Guardar usuario responsable y fecha.

## HU-07 Derivar a judicial
Como riesgos o comite, quiero derivar casos con 121 dias o mas, para iniciar cobranza judicial.

RF:
- Validar dias de mora >= 121.
- Bloquear roles sin permiso.
- Registrar evidencia en historial.

## HU-08 Proponer castigo
Como comite o gerencia, quiero proponer castigo para casos mayores a 180 dias, para cerrar cartera irrecuperable.

RF:
- Validar dias de mora > 180.
- Bloquear roles sin permiso.
- Registrar accion de castigo.

## HU-09 Controlar acceso interno
Como administrador, quiero que el Core use JWT y RBAC, para proteger acciones criticas.

RF:
- Login interno con token.
- Rutas protegidas.
- Respuesta 401 sin token.
- Respuesta 403 sin rol autorizado.
