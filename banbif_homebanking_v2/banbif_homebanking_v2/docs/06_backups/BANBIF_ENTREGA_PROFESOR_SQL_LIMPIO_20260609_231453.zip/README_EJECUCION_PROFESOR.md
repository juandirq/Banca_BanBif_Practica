﻿# EJECUCION COMPLETA - BANBIF HOMEBANKING + CORE FINANCIERO

Este paquete permite crear la base de datos desde cero y cargar todos los datos del proyecto.

## Base de datos creada

bd_core_financiero

## Forma de ejecucion

1. Abrir PowerShell dentro de esta carpeta:

sql\entrega_profesor

2. Ejecutar:

Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

3. Luego ejecutar:

.\EJECUTAR_TODO_PROFESOR.ps1

4. El script pedira la password del usuario PostgreSQL postgres.

## Que hace el script

1. Se conecta a la base postgres.
2. Elimina bd_core_financiero si existe.
3. Crea bd_core_financiero.
4. Crea tablas.
5. Inserta roles, usuarios Core, clientes, cuentas, movimientos, pagos, creditos, desembolsos, mora y recuperaciones.
6. Crea vistas para Power BI.
7. Ejecuta una validacion final.

## Archivos del paquete

- 00_CREAR_BASE_DATOS.sql  
  Crea la base de datos bd_core_financiero.

- 01_TODO_SCHEMA_Y_DATOS.sql  
  Crea la estructura e inserta datos.

- 02_VALIDACION_FINAL_PROFESOR.sql  
  Valida conteos, cartera, mora, creditos, desembolsos, recuperaciones, roles y vistas.

- EJECUTAR_TODO_PROFESOR.ps1  
  Ejecuta todo automaticamente desde PowerShell.

## Usuarios de prueba

Homebanking:

- 74851263 / 123456
- 81000001 / 123456
- 81000021 / 123456
- 81000045 / 123456

Core Financiero:

- maria.n1 / 123456
- carlos.n2 / 123456
- valeria.n3 / 123456
- jorge.riesgos / 123456
- agencia.admin / 123456
- comite.creditos / 123456
- gerencia.finanzas / 123456
- juan.admin / 123456

## Nota

Los datos son sinteticos y academicos. No corresponden a personas reales.
